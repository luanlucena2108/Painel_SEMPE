# Painel SEMPE — Indicadores Estratégicos

Painel público de indicadores da Subsecretaria de Empreendedorismo e Produtividade (SEMPE/SDE-SP).

**🔗 Acesse:** https://luanlucena2108.github.io/Painel_SEMPE

## Como funciona

- O arquivo `SEMPE_Base_PowerBI_2025_preenchida.xlsx` é a fonte de dados
- O GitHub Actions roda todo dia às 07h e gera `docs/dados.json` automaticamente
- O painel lê o JSON e atualiza todos os indicadores

## Para atualizar os dados

1. Atualize o arquivo `SEMPE_Base_PowerBI_2025_preenchida.xlsx` na raiz do repositório
2. Faça commit e push
3. O painel atualiza automaticamente na próxima execução às 07h
4. Ou rode manualmente: **Actions → Atualizar Painel SEMPE → Run workflow**

## Estrutura

```
├── SEMPE_Base_PowerBI_2025_preenchida.xlsx  ← planilha de dados
├── scripts/
│   └── gerar_json.py                        ← lê Excel → gera JSON
├── docs/
│   ├── index.html                           ← painel (GitHub Pages)
│   └── dados.json                           ← gerado automaticamente
└── .github/workflows/
    └── atualizar.yml                        ← agendamento diário 07h
```
